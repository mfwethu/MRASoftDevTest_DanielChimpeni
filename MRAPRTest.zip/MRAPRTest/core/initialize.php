<?php

define('DS')? null: define('DS', DIRECTORY_SEPARATOR);
define('SITE_ROOT')? null : define('SITE_ROOT', DS. 'wamp64'.DS.'www'.DS.'PHPRest');
define('INC_PATH')? null : define ('INC_PATH',SITE_ROOT.DS.'include');
define('CORE_PATH')? null : define ('CORE_PATH',SITE_ROOT.DS.'CORE');

require_once(INC_PATH.DS."confg.php");

require_once(CORE_PATH.DS."post.php");

?>