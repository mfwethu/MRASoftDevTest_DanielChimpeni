<?php $form_path='addtaxpayer_files/formoid1/form.php'; require_once $form_path; ?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Create/Add Taxpayer - Formoid contact form html</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="blurBg-false" style="background-color:#EBEBEB">

<?php

$url = 'https://www.mra.mw/sandbox/programming/challenge/webservice/Taxpayers/add';

$auth_data = array(
	'client_id' 		=> 'dchimpeni@gmail.com',
	'client_secret' 	=> '3fdb48c5-336b-47f9-87e4-ae73b8036a1c',
	'grant_type' 		=> 'password000122'
);

$data = array("TPIN" => "TPIN","Business Certificate Number" => "Business Certificate Number","Trading Name" => "Trading Name",
"Business Registration Date" => "Business Registration Date", "phone" => 'phone', "Email" => "Email","PhysicalLocation" => 'PhysicalLocation', "Username" => 'Username');

$postdata = json_encode($data);

$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
print_r ($result);

?>

</body>
</html>
