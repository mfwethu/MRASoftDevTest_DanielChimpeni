<?php $form_path='getall_files/formoid1/form.php'; require_once $form_path; ?><!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Get All Taxpayers - Formoid contact form</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
</head>
<body class="blurBg-false" style="background-color:#EBEBEB">

<?php
$url = 'https://www.mra.mw/sandbox/programming/challenge/webservice/Taxpayers/getAll';

$auth_data = array(
	'client_id' 		=> 'dchimpeni@gmail.com',
	'client_secret' 	=> '3fdb48c5-336b-47f9-87e4-ae73b8036a1c',
	'grant_type' 		=> 'password000122'
);

$data = $url;

$postdata = json_encode($data);

$ch = curl_init($url); 
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); 
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
$result = curl_exec($ch);
curl_close($ch);
print_r ($result);

?>

</body>
</html>
